# ===========================================================================
# Generic configuration options for building the RedisX library (both static 
# and shared).
#
# You can include this snipplet in your Makefile also.
# ============================================================================

# Location under which the Smithsonian/xchange library is installed.
# (I.e., the root directory under which there is an include/ directory
# that contains xchange.h, and a lib/ or lib64/ directory that contains
# libxchange.so
XCHANGE ?= /usr

# Folders in which sources and header files are located, respectively
SRC ?= src
INC ?= include

# Folders for compiled objects, libraries, and binaries, respectively 
OBJ ?= obj
BIN ?= bin

# Compiler: use gcc by default
CC ?= gcc

# Whether to use OpenMP. If not defined, we'll enable it automatically if 
# libgomp is available
#WITH_OPENMP = 1

# Whether to build with TLS support (via OpenSSL). If not defined, we'll
# enable it automatically if libssl is available
#WITH_TLS = 1

# Add include/ directory
CPPFLAGS += -I$(INC)

# Base compiler options (if not defined externally...)
CFLAGS ?= -g -Os -Wall

# Extra linker flags (if any)
#LDFLAGS=

# cppcheck options for 'check' target
CHECKOPTS ?= --enable=performance,warning,portability,style --language=c \
            --error-exitcode=1 --inline-suppr --std=c99 -D_USE_PTHREAD=1

# Add-on ccpcheck options
CHECKOPTS += --inline-suppr $(CHECKEXTRA)

# Exhaustive checking for newer cppcheck
#CHECKOPTS += --check-level=exhaustive

# Specific Doxygen to use if not the default one
#DOXYGEN ?= /opt/bin/doxygen

# ============================================================================
# END of user config section. 
#
# Below are some generated constants based on the one that were set above
# ============================================================================

# If XCHANGE is defined convert to absolute path for sub-makes.
ifdef XCHANGE
  XCHANGE := $(shell cd $(XCHANGE); pwd)
  export XCHANGE
endif

ifneq ($(shell which ldconfig), )
  # Detect OpenSSL automatically, and enable TLS support if present
  ifndef WITH_TLS
    ifneq ($(shell ldconfig -p | grep libssl), )
      WITH_TLS = 1
    else
      WITH_TLS = 0
    endif
  endif

  # Detect OpenMP automatically, and enable WITH_OPENMP support if present
  ifndef WITH_OPENMP
    ifneq ($(shell ldconfig -p | grep libomp), )
      WITH_OPENMP = 1
    else
      WITH_OPENMP = 0
    endif
  endif
endif

# Link against math libs (for e.g. isnan()), and xchange dependency
LDFLAGS += -lm -lxchange

# Compile for specific C standard
ifdef CSTANDARD
  CFLAGS += -std=$(CSTANDARD)
endif

# Add source code fortification checks
ifdef FORTIFY 
  CFLAGS += -D_FORTIFY_SOURCE=$(FORTIFY)
endif

ifeq ($(WEXTRA),1)
  CFLAGS += -Wextra
endif

ifdef FNMATCH_C
  CPPFLAGS += -DFNMATCH=1
endif

ifeq ($(WITH_OPENMP),1)
  CPPFLAGS += -DWITH_OPENMP=1
  CFLAGS += -fopenmp
  LDFLAGS += -fopenmp
endif

ifeq ($(WITH_TLS),1)
  CPPFLAGS += -DWITH_TLS=1
  LDFLAGS += -lssl
endif

# Search for libraries under LIB
ifneq ($(findstring $(LIB),$(LD_LIBRARY_PATH)),$LIB)
  LDFLAGS += -L$(LIB)
endif

# Compile and link against a specific xchange library (if defined)
ifdef XCHANGE
  CPPFLAGS += -I$(XCHANGE)/include
  LDFLAGS += -L$(XCHANGE)/lib
endif

# Build static or shared libs
ifeq ($(STATICLINK),1)
  LIBREDISX = $(LIB)/libredisx.a
else
  LIBREDISX = $(LIB)/libredisx.so
endif


# Search for files in the designated locations
vpath %.h $(INC)
vpath %.c $(SRC)
vpath %.o $(OBJ)
vpath %.d dep 

