# Changelog

All notable changes to the [Sigmyne/smax-clib](https://github.com/Sigmyne/smax-clib) library will be 
documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to 
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [1.1.0-rc1] - 2026-09-15

Upcoming feature release, with major build and portability enhancements, possibly around 15 October 2026.

### Added

 - #26: Added CMake build support and CI workflow.

### Changed

 - #16: Use `XBoolean` instead of `boolean` type (requires xchange v1.3).
 
 - #26: Updated CI workflows.
 
 - #28: Portability beyond POSIX, mainly to Windows (and also perhaps Android). Requires RedisX &gt;= 1.1.0 and xchange 
   &gt;= 1.3.0.
 
 - Implicit or explicit `LIB` directory in `Makefile`s.
 
 - The latest GitHub Actions tools.


## [1.0.1] - 2026-06-23

Maintenance release, with bug fixes and various improvements.

### Fixed

 - Fixed `smaxStringToValues()` for `XLLONG` type.
 
 - Conditional assignment of optional arg in `smaxParseTime()`.
 
 - Fix name matching in `smaxGetCoordinateAxis()`. Previously, the conditions for matching were inverted.
 
 - Fix update notification storage allocation (was allocating for message size rather than ID length).

 - Various issues fixed that were potted by Facebook's infer v1.3.
 
 - Various issues fixed that were spotted by GitHub Copilot AI.

### Changed

 - Hash algorithms switched to FNV-1a.

 - Use `x_snprintf()` instead of `sprintf()` when possible.

 - Printing of `size_t` values (in debug mode).
 
 - Bumbed default internal lookup cache size to 1024 slots (from 256).
 
 - Uses `xIsDebug()` global function instead of `xDebug` global var, for better compatibility with Windows DLLs.
 
 - Various `Makefile` improvements.
 
 - Changed progress message format, with fixed width percentage in square brackets and '%' at end, e.g. "[100.0%] "
   before the message body.
 
 - On older platforms without `vsnprintf()`, progress messages of up to 8 kB are supported. Attempt to send longer 
   progress messages will result in program exit with an error. (Platforms with `vsnprintf()` support can send 
   progress messages of arbitrary size.
   
 - Progress messages enforce progress fraction in the [0.0:1.0] range. Out-of-bound input values are automatically 
   changed to the nearest bounding value (e.g. -1.0 to 0.0; 1.1 to 1.0).
 

## [1.0.0] - 2026-02-16

Initial public release.
